package AdminClass;

public class Movies {
	private String mname;
	private int mid=0;
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public int getMid() {
		return mid;
	}
	public void setMid(int mid) {
		this.mid = mid;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	private String link;
	public Movies(String mname, String link) {
		super();
		this.mname = mname;
		this.link = link;
	}
	public Movies(String mname, int mid, String link) {
		super();
		this.mname = mname;
		this.mid = mid;
		this.link = link;
	}
	@Override
	public String toString() {
		return "Movies [mname=" + mname + ", mid=" + mid + ", link=" + link + "]";
	}
	
	

	
	
}
