package AdminClass;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.management.remote.JMXConnector;

import com.mysql.cj.protocol.Resultset;

import AllJavaCode.JDBCConnection;

public class IntoMovieTable {
	public void intoMovieTable(Movies m) throws ClassNotFoundException, SQLException {
		Connection sql = JDBCConnection.getConnection();
		PreparedStatement ps = sql.prepareStatement("insert into movie values(?,?,?)");
		ps.setInt(1, 0);
		ps.setString(2, m.getMname());
		ps.setString(3, m.getLink());
		ps.execute();
		sql.commit();
	}
	public List<Movies> sendMovieList() throws ClassNotFoundException, SQLException{
		List<Movies> mlist = new ArrayList<>();
		Connection sql = JDBCConnection.getConnection();
		Statement st = sql.createStatement();
		ResultSet rs = st.executeQuery("select * from movie");
		while(rs.next()) {
			String mname = rs.getString(2);
			int mid =  rs.getInt(1);
			String link = rs.getString(3);
			mlist.add(new Movies(mname, mid, link));
		}
		return mlist;
		
	}

}
