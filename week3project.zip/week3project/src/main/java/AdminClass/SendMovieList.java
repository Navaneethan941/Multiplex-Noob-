package AdminClass;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import AllJavaCode.JDBCConnection;

public class SendMovieList {
	public List<Movies> sendmovielist() throws ClassNotFoundException, SQLException {
		List<Movies> mlist = new ArrayList<>();
		Connection sql = JDBCConnection.getConnection();
		Statement st = sql.createStatement();
		ResultSet rs = st.executeQuery("select * from movie");
		while(rs.next()) {
			String mname = rs.getString(2);
			int mid =  rs.getInt(1);
			String link = rs.getString(3);
			mlist.add(new Movies(mname,mid,link));
		}
		return mlist;
	}

}
