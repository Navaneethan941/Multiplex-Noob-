package AdminClass;

import java.sql.SQLException;

public class TestMovie {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Movies m = new Movies("24");
		SendMovieList mov = new SendMovieList();
		try {
			//into.intoMovieTable(m);
			System.out.println(mov.sendmovielist());
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
