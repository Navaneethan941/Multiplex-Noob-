package AllJavaCode;

import java.sql.SQLException;

public class TestIntoTable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InsertIntoUserTable a = new InsertIntoUserTable();
		try {
			a.insertintousertable(new MultipluxUser("heorld", "u", 1234567890, "navaneethan@gmail.com", "navaneethan@"));
			SendUserList s = new SendUserList();
			System.out.println(s.senduserlist());
			System.out.println("good");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("not done");
			e.printStackTrace();
		}

	}

}
