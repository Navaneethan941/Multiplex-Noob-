package AllJavaCode;

import java.io.Reader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mysql.cj.protocol.Resultset;

public class SendUserList {
	public List<MultipluxUser> senduserlist() throws ClassNotFoundException, SQLException {
		List<MultipluxUser> userlist = new ArrayList<>();
		Connection sql =  JDBCConnection.getConnection();
		Statement st = sql.createStatement();
		ResultSet rset = st.executeQuery("Select* from user");
		while(rset.next()) {
			int uid = rset.getInt(1);
			String name  = rset.getString(2);
			String type =rset.getString(3);
			Long mno = rset.getLong(4);
			String email = rset.getString(5);
			String pword = rset.getString(6);
			MultipluxUser u = new MultipluxUser(name, type, mno, email, pword,uid);
			userlist.add(u);
		}
		return userlist;
	}
}
