package AllJavaCode;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



import com.mysql.cj.protocol.Resultset;

public class InsertIntoUserTable {
	public void insertintousertable(MultipluxUser u) throws ClassNotFoundException, SQLException  {
		Connection sql = JDBCConnection.getConnection();
		PreparedStatement pr = sql.prepareStatement("insert into user values(?,?,?,?,?,?)");
		pr.setInt(1, 0);
		pr.setString(2, u.getName());
		pr.setString(3, u.getUsertype());
		pr.setLong(4, u.getMobileno());
		pr.setString(5, u.getEmail());
		pr.setString(6, u.getPassword());
		pr.execute();
		sql.commit();
	}

}
