package AllJavaCode;

public class MultipluxUser {
	private String name;
	private String usertype;
	private long mobileno;
	private String email;
	private String password;
	private int uid=0;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUsertype() {
		return usertype;
	}
	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}
	public long getMobileno() {
		return mobileno;
	}
	public void setMobileno(long mobileno) {
		this.mobileno = mobileno;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public MultipluxUser(String name, String usertype, long mobileno, String email, String password) {
		super();
		this.name = name;
		this.usertype = usertype;
		this.mobileno = mobileno;
		this.email = email;
		this.password = password;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public MultipluxUser(String name, String usertype, long mobileno, String email, String password, int uid) {
		super();
		this.name = name;
		this.usertype = usertype;
		this.mobileno = mobileno;
		this.email = email;
		this.password = password;
		this.uid = uid;
	}
	@Override
	public String toString() {
		return "MultipluxUser [name=" + name + ", usertype=" + usertype + ", mobileno=" + mobileno + ", email=" + email
				+ ", password=" + password + ", uid=" + uid + "]";
	}
	
	
	
}
