package For.hall;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mysql.cj.protocol.Resultset;

import AllJavaCode.JDBCConnection;

public class SendHallList {
	public List<Hall> sendhalllist() throws ClassNotFoundException, SQLException {
		Connection sql = JDBCConnection.getConnection();
		List hall = new ArrayList<>();
		Statement s = sql.createStatement();
		ResultSet rs = s.executeQuery("select * from hall");
		while(rs.next()) {
			hall.add(new Hall(rs.getInt(1), rs.getString(2)));
		}
		return hall;
	}

	

}
