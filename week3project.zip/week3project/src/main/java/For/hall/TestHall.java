package For.hall;

import java.sql.SQLException;

public class TestHall {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SendHallList hall = new SendHallList();
		try {
			System.out.println(hall.sendhalllist());
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
