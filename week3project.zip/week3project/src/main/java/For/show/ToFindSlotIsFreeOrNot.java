package For.show;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.mysql.cj.protocol.Resultset;

import AllJavaCode.JDBCConnection;

public class ToFindSlotIsFreeOrNot {
	public void tofindslotisfreeornot(Show s) throws ClassNotFoundException, SQLException {
		List<Show> showlist = new ArrayList<>();
		Connection sql = JDBCConnection.getConnection();
		Statement st = sql.createStatement();
		ResultSet rs = st.executeQuery("select * from shows where (fromdate between '"+s.getFromDate()+
				"' and '"+s.getToDate()+"')"+
				"and (hall_id='"+ s.getHallId()+"') and (slot_no='"+s.getShowId()+"')");
//		ResultSet rs = st.executeQuery("select * from shows where (fromdate between '2022-09-06' and '2022-09-10')"
//				+ "and (hall_id='1') and (slot_no='1')");
//		ResultSet rs = st.executeQuery("select * from shows where date(now())  between '2022-09-06' and '2022-09-10';");
//		System.out.println(s.getFromDate());
		while(rs.next()) {
			System.out.println("hello");
			int showId = rs.getInt(1);
			int hallId = rs.getInt(2);
			int movidId = rs.getInt(3);
			int slotId = rs.getInt(4);
			Date fromdate =(Date)rs.getDate(5);
			Date todate = (Date)rs.getDate(6);
			Show s1 = new Show(showId, hallId, movidId, slotId, fromdate, todate);
			System.out.println(s1);
			showlist.add(s1);
		}
		System.out.println("hello");
		System.out.println(showlist.size());
	}

}
