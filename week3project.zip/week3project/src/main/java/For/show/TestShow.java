package For.show;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class TestShow {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IntoShowsTabale table = new IntoShowsTabale();
		SendShowList show = new SendShowList();
		SendShowUserList shows = new SendShowUserList();
		try {
			//table.intoshowstabale(new Show(1, 1, 1, "06/09/2022", "10/09/2022"));
			//System.out.println(show.sendshowlist());
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate fromdate1 = LocalDate.parse("06/09/2022", formatter);
			LocalDate todate1 = LocalDate.parse("10/09/2022", formatter);
			
			Date fromdate = java.sql.Date.valueOf(fromdate1);
			Date todate = java.sql.Date.valueOf(todate1);
			Show show1 = new Show(1, 1, 1, fromdate, todate);
			System.out.println(show1);
			System.out.println(shows.SendShowUserList());
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
