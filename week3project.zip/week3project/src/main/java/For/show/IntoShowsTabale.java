package For.show;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import AllJavaCode.JDBCConnection;

public class IntoShowsTabale {
	public void intoshowstabale(Show s) throws ClassNotFoundException, SQLException {
		Connection sql = JDBCConnection.getConnection();
		PreparedStatement pr = sql.prepareStatement("insert into shows values(?,?,?,?,?,?)");
		pr.setInt(2, s.getHallId() );
		pr.setInt(3, s.getMovieId());
		pr.setInt(4, s.getSlotNo());
		pr.setDate(5, (Date) s.getFromDate());
		pr.setDate(6, (Date) s.getToDate());
		pr.setInt(1, 0);
		pr.execute();
		sql.commit();
	}

}
