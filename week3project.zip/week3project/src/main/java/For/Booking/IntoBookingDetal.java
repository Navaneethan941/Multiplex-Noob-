package For.Booking;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import AllJavaCode.JDBCConnection;

public class IntoBookingDetal {
	public void intobookingdetal(BookingDetal b) throws ClassNotFoundException, SQLException {
		Connection sql = JDBCConnection.getConnection();
		PreparedStatement ps = sql.prepareStatement("insert into bookingdetal values(?,?,?)");
		ps.setString(1, b.getBookingid());
		ps.setInt(2, b.getSeattypeid());
		ps.setInt(3, b.getNoofseat());
		ps.execute();
		sql.commit();
		
	}

}
