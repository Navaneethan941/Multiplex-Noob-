package For.Booking;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import AllJavaCode.JDBCConnection;

public class IntoBookingTable {
	public void intobookingtable(Booking b) throws ClassNotFoundException, SQLException {
		Connection sql = JDBCConnection.getConnection();
		PreparedStatement ps = sql.prepareStatement("insert into booking values(?,?,?,?,?)");
		ps.setString(1, b.getBookingid());
		ps.setInt(2, b.getShowid());
		ps.setInt(3, b.getUserid());
		ps.setDate(4, (Date) b.getBookingdate());
		ps.setDate(5, (Date)b.getShowDate() );
		ps.execute();
		sql.commit();
	}

}
