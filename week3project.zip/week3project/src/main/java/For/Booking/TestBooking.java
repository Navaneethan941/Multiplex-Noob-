package For.Booking;

import java.sql.SQLException;

public class TestBooking {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SendRowOfHallCapacity avi = new SendRowOfHallCapacity();
		ToUpdateAvailableInTable update = new ToUpdateAvailableInTable();
		try {
			System.out.println(avi.sendrowofhallcapacity(1, 1));
			update.toupdateavailableintable(39, 1, 1);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
