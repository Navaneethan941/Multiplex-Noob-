package For.Booking;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.cj.protocol.Resultset;

import AllJavaCode.JDBCConnection;

public class SendRowOfHallCapacity {
	public int sendrowofhallcapacity(int hallid,int seatid) throws ClassNotFoundException, SQLException {
		Connection sql = JDBCConnection.getConnection();
		int seatavailable=-1;
		Statement st = sql.createStatement();
		ResultSet rs = st.executeQuery("select * from hallcapacity where"
				+ " hall_id= '"+hallid+"' and seat_type = '"+seatid+"'");
		while(rs.next()) {
			seatavailable = rs.getInt(4);
		}
		return seatavailable;
		
	}

}
