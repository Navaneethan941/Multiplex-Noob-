package For.Booking;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import AllJavaCode.JDBCConnection;

public class ToUpdateAvailableInTable {
	public void toupdateavailableintable(int available,int hallid ,int seatid) throws ClassNotFoundException, SQLException {
		Connection sql = JDBCConnection.getConnection();
		Statement st = sql.createStatement();
		st.execute("update hallcapacity set Seat_available = "+available+" where hall_id="+hallid+
				" and seat_type ="+seatid);
		sql.commit();
	}

}
