package Report;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import AllJavaCode.JDBCConnection;

public class UpdateReport {
	public void updatereport(String bookingid) throws ClassNotFoundException, SQLException {
		Connection sql = JDBCConnection.getConnection();
		Statement st = sql.createStatement();
		st.execute("update report set _status = false where bookingid ='"+bookingid+"'");
		sql.commit();
	}

}
