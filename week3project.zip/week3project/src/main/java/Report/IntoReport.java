package Report;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.cj.jdbc.JdbcConnection;

import AllJavaCode.JDBCConnection;

public class IntoReport {
	public void intoreport(String bookingid, float price) throws ClassNotFoundException, SQLException {
		Connection sql = JDBCConnection.getConnection();
		PreparedStatement pr = sql.prepareStatement("insert into report values(?,?,?)");
		pr.setString(1, bookingid);
		pr.setFloat(2, price);
		pr.setBoolean(3, true);
		pr.execute();
		sql.commit();
	}
}
