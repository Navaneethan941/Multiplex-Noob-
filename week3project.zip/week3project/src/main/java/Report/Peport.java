package Report;

public class Peport {
	private String bookingid;
	private float price;
	private boolean status;
	public String getBookingid() {
		return bookingid;
	}
	public void setBookingid(String bookingid) {
		this.bookingid = bookingid;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public Peport(String bookingid, float price, boolean status) {
		super();
		this.bookingid = bookingid;
		this.price = price;
		this.status = status;
	}
	@Override
	public String toString() {
		return "Peport [bookingid=" + bookingid + ", price=" + price + ", status=" + status + "]";
	}
	

}
