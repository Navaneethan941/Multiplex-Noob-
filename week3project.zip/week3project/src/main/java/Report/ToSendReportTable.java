package Report;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mysql.cj.protocol.Resultset;

import AllJavaCode.JDBCConnection;

public class ToSendReportTable {
	public List<Peport> tosendreporttable() throws ClassNotFoundException, SQLException {
		Connection sql = JDBCConnection.getConnection();
		List<Peport> reportlist = new ArrayList<>();
		Statement st  = sql.createStatement();
		ResultSet rs = st.executeQuery("Select * from report");
		while(rs.next()) {
			String bookingid = rs.getString(1);
			float price = rs.getFloat(2);
			boolean ststus = rs.getBoolean(3);
			reportlist.add(new Peport(bookingid, price, ststus));
		}
		return reportlist;
	}

}
