package Report;

import java.sql.SQLException;

public class TestReport {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ToSendReportTable table = new ToSendReportTable();
		try {
			System.out.println(table.tosendreporttable());
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
