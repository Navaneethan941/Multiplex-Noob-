package AllServlet;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import For.Booking.Booking;
import For.Booking.BookingDetal;
import For.Booking.IntoBookingDetal;
import For.Booking.IntoBookingTable;
import For.Booking.SendRowOfHallCapacity;
import For.Booking.ToUpdateAvailableInTable;
import Report.IntoReport;

/**
 * Servlet implementation class ServletForBooking
 */
@WebServlet("/ServletForBooking")
public class ServletForBooking extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletForBooking() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String hallname = request.getParameter("Hall");
		String seattype = request.getParameter("SeatType");
		int avilablrseat  = Integer.parseInt(request.getParameter("SeatAvailable"));
		int userid =Integer.parseInt(request.getParameter("uid"));
		int halid = Integer.parseInt(request.getParameter("Hallid"));
		int seatid = Integer.parseInt(request.getParameter("Seatid"));
		float price = Float.parseFloat(request.getParameter("Price"));
		String mname = request.getParameter("Mname");
		
		Random random = new Random();  
		int y = random.nextInt(999999); 
		
		String bookingid = mname+String.valueOf(userid)+hallname+seattype+String.valueOf(avilablrseat+y);
		
		int showid = Integer.parseInt(request.getParameter("ShowId"));
		
		LocalDate today = LocalDate.now();
		Date today1 = java.sql.Date.valueOf(today);
		
		String showdate = request.getParameter("showdate");
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate showdate1 = LocalDate.parse(showdate, formatter);
		Date showdate2 = java.sql.Date.valueOf(showdate1);
		
		int available=-1;
		int noonseat = Integer.parseInt(request.getParameter("noofseat"));
		
		Booking book1 = new Booking(bookingid,showid, userid, today1, showdate2);
		BookingDetal deatle = new BookingDetal(bookingid, seatid, noonseat);
		IntoBookingTable b1 = new IntoBookingTable();
		IntoBookingDetal b2 = new IntoBookingDetal();
		
		SendRowOfHallCapacity avl = new SendRowOfHallCapacity();
		ToUpdateAvailableInTable update = new ToUpdateAvailableInTable();
		IntoReport report = new IntoReport();
		try {
			available = avl.sendrowofhallcapacity(halid, seatid);
			available -=noonseat;
			update.toupdateavailableintable(available, halid, seatid);
			report.intoreport(bookingid, price);
			System.out.println("good");
			b1.intobookingtable(book1);
			b2.intobookingdetal(deatle);
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.setAttribute("userid",userid );
		RequestDispatcher rq = request.getRequestDispatcher("UserInterface.jsp");
		rq.forward(request, response);
		
		
		response.getWriter().append(bookingid+" "+halid+" "+seatid);
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
