package AllServlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import For.Booking.SendRowOfHallCapacity;
import For.Booking.ToUpdateAvailableInTable;
import ForCancelling.ToRemoveFromBooking;
import Report.UpdateReport;

/**
 * Servlet implementation class ServletForCancelling
 */
@WebServlet("/ServletForCancelling")
public class ServletForCancelling extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletForCancelling() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String bookingId = request.getParameter("Bookingid");
		int hallid = Integer.parseInt(request.getParameter("Hallid"));
		int seattypeid =Integer.parseInt(request.getParameter("Seattypeid"));
		int noofseat = Integer.parseInt(request.getParameter("Noofseat"));
		System.out.println(request.getParameter("Userid")+" problem");
		int userid = Integer.parseInt(request.getParameter("Userid"));
		SendRowOfHallCapacity avl = new SendRowOfHallCapacity();
		ToUpdateAvailableInTable update = new ToUpdateAvailableInTable();
		ToRemoveFromBooking remove = new ToRemoveFromBooking();
		int available=-1;
		try {
			available = avl.sendrowofhallcapacity(hallid, seattypeid);
			available+=noofseat;
			update.toupdateavailableintable(available, hallid, seattypeid);
			UpdateReport up = new UpdateReport();
			up.updatereport(bookingId);
			remove.toremovefrombooking(bookingId);
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.setAttribute("userid",userid );
		RequestDispatcher rq = request.getRequestDispatcher("UserInterface.jsp");
		rq.forward(request, response);
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
