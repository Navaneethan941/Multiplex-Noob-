package AllServlet;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import For.show.IntoShowsTabale;
import For.show.Show;

/**
 * Servlet implementation class ServletForInsertIntoShowsTable
 */
@WebServlet("/ServletForInsertIntoShowsTable")
public class ServletForInsertIntoShowsTable extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletForInsertIntoShowsTable() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stubt
		int hallid = Integer.parseInt(request.getParameter("hallid"));
		int movidid = Integer.parseInt(request.getParameter("movidid"));
		int slot = Integer.parseInt(request.getParameter("slot"));
		String fromdate = request.getParameter("fromdate");
		String todate = request.getParameter("todate");
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate fromdate1 = LocalDate.parse(fromdate, formatter);
		
		LocalDate todate1 = LocalDate.parse(todate, formatter);
		
		Date fromdate2 = java.sql.Date.valueOf(fromdate1);
		Date todate2 = java.sql.Date.valueOf(todate1);
		
		Show show = new Show(hallid, movidid, slot, fromdate2, todate2);
		IntoShowsTabale into = new IntoShowsTabale();
		try {
			into.intoshowstabale(show);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
