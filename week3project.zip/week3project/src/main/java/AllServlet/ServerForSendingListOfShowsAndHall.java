package AllServlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import AdminClass.SendMovieList;
import For.hall.SendHallList;
import For.show.SendShowList;

/**
 * Servlet implementation class ServerForSendingListOfShowsAndHall
 */
@WebServlet("/ServerForSendingListOfShowsAndHall")
public class ServerForSendingListOfShowsAndHall extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServerForSendingListOfShowsAndHall() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		SendMovieList movies = new SendMovieList();
		SendHallList hall = new SendHallList();
		SendShowList show = new SendShowList();
		try {
			request.setAttribute("movielist", movies.sendmovielist());
			request.setAttribute("halllist", hall.sendhalllist());
			request.setAttribute("showlist", show.sendshowlist());
			RequestDispatcher rs = request.getRequestDispatcher("Admin_insert_into_show.jsp");
			rs.forward(request, response);
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
