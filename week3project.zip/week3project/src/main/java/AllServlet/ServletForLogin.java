package AllServlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import AllJavaCode.MultipluxUser;
import AllJavaCode.SendUserList;

/**
 * Servlet implementation class ServletForLogin
 */
@WebServlet("/ServletForLogin")
public class ServletForLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletForLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		List <MultipluxUser>userlist = new ArrayList<>();
		SendUserList s = new SendUserList();
		try {
			String email=request.getParameter("email");
			String pword=request.getParameter("pword");
			String type = request.getParameter("type");
			type = String.valueOf(type.charAt(0));
			boolean ok = true;
			userlist.addAll(s.senduserlist());
			for (MultipluxUser u : userlist) {
//				System.out.println(u.getEmail()+" "+email+" "+u.getPassword()+" "+pword+" "+u.getUsertype()+" "+type);
//			    System.out.println(u.getEmail().equals(email));
//			    System.out.println(u.getPassword().equals(pword));
//			    System.out.println(u.getUsertype().equals(type));
				if(u.getEmail().equals(email) && u.getPassword().equals(pword) && u.getUsertype().equals(type)&&u.getUsertype().equals("u")) {
					response.getWriter().append("user log in");
					ok= false;
					request.setAttribute("userid",u.getUid());
					RequestDispatcher rd = request.getRequestDispatcher("UserInterface.jsp");
					rd.forward(request, response);
					break;
				}
				if(u.getEmail().equals(email) && u.getPassword().equals(pword) && u.getUsertype().equals(type)&&u.getUsertype().equals("a")) {
					response.getWriter().append("admin log in");
					ok= false;
					RequestDispatcher rd = request.getRequestDispatcher("Admin_interface.html");
					rd.forward(request, response);
					break;
				}
			}
			if(ok) {
				response.getWriter().append("username or password is wrong");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
