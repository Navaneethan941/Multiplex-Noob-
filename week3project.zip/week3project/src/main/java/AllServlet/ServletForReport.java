package AllServlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Report.Peport;
import Report.ToSendReportTable;

/**
 * Servlet implementation class ServletForReport
 */
@WebServlet("/ServletForReport")
public class ServletForReport extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletForReport() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		List<Peport> report = new ArrayList<>();
		ToSendReportTable re = new ToSendReportTable();
		try {
			report.addAll(re.tosendreporttable());
			
			int activetecket =0;
			int calcledtecket =0;
			float activetecketvalue=0f;
			float calcledtecketvalue =0f;
			float totalvalue = 0f;
			for (Peport rep : report) {
				if(rep.isStatus()) {
					activetecket++;
					activetecketvalue+=rep.getPrice();
				}else {
					calcledtecket++;
					calcledtecketvalue+=rep.getPrice();
				}
			}
			calcledtecketvalue*=.2;
			totalvalue+=calcledtecketvalue+activetecketvalue;
			request.setAttribute("activetecket", activetecket);
			request.setAttribute("calcledtecket", calcledtecket);
			request.setAttribute("activetecketvalue", activetecketvalue);
			request.setAttribute("calcledtecketvalue", calcledtecketvalue);
			request.setAttribute("totalvalue", totalvalue);
			RequestDispatcher rd = request.getRequestDispatcher("adminreport.jsp");
			rd.forward(request, response);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
