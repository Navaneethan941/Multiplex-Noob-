package ForCancelling;

public class Cancelling {
	private int userid;
	private String bookingid;
	private String mname;
	private String seattype;
	private int noofseat;
	private int hallid;
	private int seattypeid;
	private String hall;
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getBookingid() {
		return bookingid;
	}
	public void setBookingid(String bookingid) {
		this.bookingid = bookingid;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public String getSeattype() {
		return seattype;
	}
	public void setSeattype(String seattype) {
		this.seattype = seattype;
	}
	public int getNoofseat() {
		return noofseat;
	}
	public void setNoofseat(int noofseat) {
		this.noofseat = noofseat;
	}
	public int getHallid() {
		return hallid;
	}
	public void setHallid(int hallid) {
		this.hallid = hallid;
	}
	public int getSeattypeid() {
		return seattypeid;
	}
	public void setSeattypeid(int seattypeid) {
		this.seattypeid = seattypeid;
	}
	public String getHall() {
		return hall;
	}
	public void setHall(String hall) {
		this.hall = hall;
	}
	public Cancelling(int userid, String bookingid, String mname, String seattype, int noofseat, int hallid,
			int seattypeid, String hall) {
		super();
		this.userid = userid;
		this.bookingid = bookingid;
		this.mname = mname;
		this.seattype = seattype;
		this.noofseat = noofseat;
		this.hallid = hallid;
		this.seattypeid = seattypeid;
		this.hall = hall;
	}
	@Override
	public String toString() {
		return "Cancelling [userid=" + userid + ", bookingid=" + bookingid + ", mname=" + mname + ", seattype="
				+ seattype + ", noofseat=" + noofseat + ", hallid=" + hallid + ", seattypeid=" + seattypeid + ", hall="
				+ hall + "]";
	}
	
	

}
