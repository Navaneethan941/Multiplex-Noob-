package ForCancelling;

import java.sql.SQLException;

public class testCancelling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SendListOfBookingToUser tecket = new SendListOfBookingToUser();
		try {
			System.out.println(tecket.sendlistofbookingtouser(1));
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
