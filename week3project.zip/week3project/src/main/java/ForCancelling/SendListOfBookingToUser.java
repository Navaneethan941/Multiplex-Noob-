package ForCancelling;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import AllJavaCode.JDBCConnection;

public class SendListOfBookingToUser {
	public List<Cancelling> sendlistofbookingtouser(int uid) throws ClassNotFoundException, SQLException {
		Connection sql = JDBCConnection.getConnection();
		List<Cancelling> tecket = new ArrayList<>();
		Statement st = sql.createStatement();
		ResultSet rs = st.executeQuery("select b.user_id , b.booking_id, m.movie_name,"
				+ " st.seat_type , bd.noofseat, s.hall_id, bd.Seattype_id, h.hallname"
				+ " from booking b inner join shows s on b.show_id = s.show_id "
				+ "inner join movie m on s.movie_id = m.movie_id "
				+ "inner join bookingdetal bd on b.booking_id = bd.booking_id "
				+ "inner join seat_type st on bd.Seattype_id = st.seat_id "
				+ "inner join hallcapacity hc on (bd.Seattype_id = hc.seat_type)"
				+ "and(s.hall_id = hc.hall_id)"
				+ "inner join hall h on s.hall_id= h.hall_id");
		while(rs.next()) {
			int userid = rs.getInt(1);
			String bookingid = rs.getString(2);
			String mname = rs.getString(3);
			String seattype = rs.getString(4);
			int noofseat = rs.getInt(5);
			int hallid = rs.getInt(6);
			int seattypeid = rs.getInt(7);
			String hall = rs.getString(8);
			if(uid == userid)
			tecket.add(new Cancelling(userid, bookingid, mname, seattype, noofseat, hallid, seattypeid,hall));
		}
		return tecket;
	}

}
