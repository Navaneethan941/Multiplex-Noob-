package ForCancelling;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import AllJavaCode.JDBCConnection;

public class ToRemoveFromBooking {
	public void toremovefrombooking(String bookingid) throws ClassNotFoundException, SQLException {
		Connection sql = JDBCConnection.getConnection();
		Statement st = sql.createStatement();
		st.execute("delete from bookingdetal where booking_id ='"+bookingid+"'");
		st.execute("delete from booking where booking_id ='"+bookingid+"'");
		sql.commit();
	}

}
